    <link rel="stylesheet" href="css/style1.css">
    <link rel="shortcut icon" href="images/logon.png" type="image/png">
    <link rel="stylesheet" href="css/slick.css">
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="css/nice-select.css">
    <link rel="stylesheet" href="css/jquery.nice-number.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/default.css">
    <link rel="stylesheet" href="css/style.css">
    
    <!--====== Responsive css ======-->
    <link rel="stylesheet" href="css/responsive.css">
    <link rel="stylesheet" href="css/flaticon.css">
<div class="header-area header-2 d-none d-md-block">
				<div class="pl-4 pr-4">
					<div class="row">
						<div class="col-xl-7 col-lg-7 col-md-9">
							<div class="header-wrapper">
								<div class="header-text">
									<!--<span> <i class="flaticon-call"></i><-->
										<div class="icon">
                                           <span><i class="fa fa-phone"></i>
                                            +91 7093767548</span>
									         <!--<span> <i class="flaticon-email"></i> <-->
                                           <span><i class="fa fa-envelope-o"></i>
                                           <a href="mailto:znherbals@gmail.com">znherbals@gmail.com</a></span>
								        </div>
								</div>
							</div>
						</div>
						<div class="col-xl-5 col-lg-5 col-md-3">
							<div class="footer-icon text-right">
								   <a class="icon-link round facebook fill text-white"><i class="fa fa-facebook-f"></i></a>
								   <a class="icon-link round twitter fill text-white"><i class="fa fa-twitter"></i></a>
								   <a class="icon-link round youtube fill text-white"><i class="fa fa-youtube"></i></a>
							</div>
						</div>
					</div>
				</div>
			</div>

         
        </div>