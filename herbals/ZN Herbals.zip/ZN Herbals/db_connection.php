<?php
$host = "localhost";
$username = "root";
$passsword = "";
$dbname = "herbal";

$conn = new mysqli($host, $username, $passsword, $dbname);

?>